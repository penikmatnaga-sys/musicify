// server.js
// Simple Spotify-clone backend using Express + Multer
// Usage: npm install && npm start
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.static('public'));

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

// Multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const safe = Date.now() + '-' + file.originalname.replace(/\s+/g, '_');
    cb(null, safe);
  }
});
const upload = multer({ storage, limits: { fileSize: 300 * 1024 * 1024 } });

// Upload endpoint (multiple files supported)
app.post('/api/upload', upload.array('files'), (req, res) => {
  const files = (req.files || []).map(f => ({
    originalname: f.originalname,
    filename: f.filename,
    url: `/uploads/${f.filename}`,
    size: f.size
  }));
  res.json({ ok: true, files });
});

// Serve uploads (static). Express static supports range requests for streaming.
app.use('/uploads', express.static(UPLOAD_DIR, {
  setHeaders: (res, path) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
  }
}));

// List files
app.get('/api/files', (req, res) => {
  try {
    const list = fs.readdirSync(UPLOAD_DIR)
      .filter(n => !n.startsWith('.'))
      .map(filename => ({
        name: filename.replace(/^\d+-/, ''),
        filename,
        url: `/uploads/${filename}`
      }));
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: 'failed to list uploads' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server ready → http://localhost:${PORT}`));
