// script.js
const fileInput = document.getElementById('fileInput');
const uploadBtn = document.getElementById('uploadBtn');
const refreshBtn = document.getElementById('refresh');
const listEl = document.getElementById('list');
const audio = document.getElementById('audio');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const progressBar = document.getElementById('progressBar');
const progressWrap = document.getElementById('progressWrap');
const nowTitle = document.getElementById('nowTitle');
const nowSub = document.getElementById('nowSub');
const timeEl = document.getElementById('time');
const volumeEl = document.getElementById('volume');
const downloadBtn = document.getElementById('download');

let tracks = [];
let current = 0;

async function loadTracks(){
  try{
    const res = await fetch('/api/files');
    tracks = await res.json();
    renderList();
    if(tracks.length && !audio.src){
      loadTrack(0);
    }
  }catch(e){
    console.error('loadTracks error', e);
  }
}

function renderList(){
  listEl.innerHTML = '';
  if(!tracks.length){
    listEl.innerHTML = '<div class="small">Belum ada lagu. Upload dulu.</div>';
    return;
  }
  tracks.forEach((t,i) => {
    const div = document.createElement('div');
    div.className = 'track';
    div.innerHTML = `
      <div style="width:56px;height:56px;border-radius:8px;background:linear-gradient(135deg,#06b6d4,#3b82f6);display:flex;align-items:center;justify-content:center">🎵</div>
      <div class="meta">
        <div class="title">${i+1}. ${t.name}</div>
        <div class="sub">${t.url}</div>
      </div>
      <div class="actions">
        <button class="btn small" onclick="playTrack(${i})">Play</button>
        <button class="btn small" onclick="downloadTrack('${t.url}')">Download</button>
      </div>
    `;
    listEl.appendChild(div);
  });
}

function downloadTrack(url){
  const a = document.createElement('a');
  a.href = url;
  a.download = '';
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function loadTrack(idx){
  if(!tracks.length) return;
  if(idx < 0) idx = tracks.length - 1;
  if(idx >= tracks.length) idx = 0;
  current = idx;
  const t = tracks[current];
  audio.src = t.url;
  nowTitle.textContent = t.name;
  nowSub.textContent = t.url;
  highlight();
}

function highlight(){
  const nodes = listEl.querySelectorAll('.track');
  nodes.forEach((n, i) => {
    if(i === current) n.style.outline = '2px solid rgba(255,255,255,0.03)';
    else n.style.outline = 'none';
  });
}

window.playTrack = function(i){
  loadTrack(i);
  audio.play();
  playBtn.textContent = '⏸';
};

playBtn.addEventListener('click', () => {
  if(!audio.src){
    if(tracks.length) loadTrack(0);
    else return alert('Belum ada lagu. Upload dulu.');
  }
  if(audio.paused){
    audio.play();
    playBtn.textContent = '⏸';
  } else {
    audio.pause();
    playBtn.textContent = '▶️';
  }
});

prevBtn.addEventListener('click', () => {
  loadTrack(current - 1);
  audio.play();
  playBtn.textContent = '⏸';
});

nextBtn.addEventListener('click', () => {
  loadTrack(current + 1);
  audio.play();
  playBtn.textContent = '⏸';
});

audio.addEventListener('timeupdate', () => {
  const pct = (audio.currentTime / audio.duration) * 100 || 0;
  progressBar.style.width = pct + '%';
  timeEl.textContent = formatTime(audio.currentTime) + ' / ' + formatTime(audio.duration);
});

audio.addEventListener('ended', () => {
  loadTrack(current + 1);
  audio.play();
});

progressWrap.addEventListener('click', (e) => {
  const rect = progressWrap.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const pct = x / rect.width;
  audio.currentTime = pct * audio.duration || 0;
});

volumeEl.addEventListener('input', () => {
  audio.volume = Number(volumeEl.value);
});

function formatTime(s){
  if(!isFinite(s)) return '00:00';
  const m = Math.floor(s/60).toString().padStart(2,'0');
  const sec = Math.floor(s%60).toString().padStart(2,'0');
  return m + ':' + sec;
}

// upload handler
uploadBtn.addEventListener('click', async () => {
  const files = fileInput.files;
  if(!files || !files.length) return alert('Pilih file audio dulu');
  const fd = new FormData();
  for(const f of files) fd.append('files', f);
  uploadBtn.disabled = true;
  uploadBtn.textContent = 'Uploading...';
  try{
    const res = await fetch('/api/upload', { method: 'POST', body: fd });
    const data = await res.json();
    if(data.ok){
      await loadTracks();
      alert('Berhasil upload ' + data.files.length + ' file');
    } else {
      alert('Upload gagal');
    }
  }catch(err){
    console.error(err);
    alert('Error saat upload');
  }finally{
    uploadBtn.disabled = false;
    uploadBtn.textContent = 'Upload';
    fileInput.value = '';
  }
});

refreshBtn.addEventListener('click', loadTracks);
downloadBtn.addEventListener('click', () => {
  if(!tracks.length) return alert('Tidak ada lagu untuk di-download');
  downloadTrack(tracks[current].url);
});

// init
loadTracks();
