
Spotify Clone by Wahyu Zulfikar
---------------------------------

How to run locally:
1. unzip spotify-clone-wahyu.zip
2. cd spotify-clone-wahyu
3. npm install
4. npm start
5. open http://localhost:3000

Notes:
- Uploaded songs are saved to the 'uploads' folder and served publicly.
- For production, consider storage service (S3) and securing uploads.
- This project is for demo/learning purposes.
